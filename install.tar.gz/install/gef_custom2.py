def align_address(address: int) -> int:
    """Align the provided address to the process's native length."""
    if current_arch.ptrsize == 4:
        return address & 0xFFFFFFFF

    return address & 0xFFFFFFFFFFFFFFFF

def find_all_tcache():
    arena = GlibcHeap.get_arena(None)
    all_tc = []
    tcache_perthread_struct = arena.heap_base + 0x10

    nb_chunk = 0
    for i in range(GlibcHeap.GlibcArena.TCACHE_MAX_BINS):
        chunk = arena.tcachebin(i)
        chunks = []
        m = []

        # Only print the entry if there are valid chunks. Don't trust count
        while True:
            if chunk is None:
                break
            try:
                all_tc.append(chunk.address)
                if chunk.address in chunks:
                    break

                chunks.append(chunk.address)
                nb_chunk += 1

                next_chunk = chunk.get_fwd_ptr(True)
                if next_chunk == 0 or next_chunk is None:
                    break

                chunk = GlibcHeap.GlibcChunk(next_chunk)
            except gdb.MemoryError:
                all_tc.append(chunk.address)
                break

    return all_tc

@register_command
class tcache(GenericCommand):
    """Find tcache / or top tcache"""
    _cmdline_ = "tc"
    _syntax_  = f"{_cmdline_} [top]"
    TCACHE_MAX_BINS = 0x40

    @only_if_gdb_running         
    def do_invoke(self, argv):
        if len(argv) < 1:
            msg = f"All tcache bin(s): "
            for i, x in enumerate(find_all_tcache()):
                msg += hex(x)
                if i != len(find_all_tcache()) - 1:
                    if x == find_all_tcache()[find_all_tcache().index(x)+1]:
                        msg += ' ⇌  '
                    else:
                        msg += RIGHT_ARROW

            # msg = f"All tcache bin(s): {''.join([hex(x) + (' ⇌  ' if x == find_all_tcache()[find_all_tcache().index(x)+1] and i != len(find_all_tcache()) - 1 else RIGHT_ARROW if i != len(find_all_tcache()) - 1 else '') for i, x in enumerate(find_all_tcache())])}"
            # msg = f"All tcache bin(s): {''.join([hex(x) + (RIGHT_ARROW if x != find_all_tcache()[-1] else (' ⇌  ' if (x == find_all_tcache()[find_all_tcache().index(x)+1]) else ' ')) for x in find_all_tcache()])}"
            msg = Color.colorify(msg, "light_blossom")
            gef_print(msg)
            arena = GlibcHeap.get_arena(None)
            tcache_base : int = arena.heap_base + 0x10
            ctx = Color.colorify(f"Tcache base: {hex(tcache_base)}", "light_blossom")
            gdb.execute(f"xg 22 {hex(tcache_base)}")

        else:
            if argv[0] == "top":
                address = find_all_tcache()
                gdb.execute(f"xg {hex(address[0])}")

@register_command
class vis(GenericCommand):
    """print all chunks"""

    _cmdline_ = "vis"
    _syntax_  = f"{_cmdline_} [max_size]"
    _category_ = "06-a. Heap - Glibc"
    _repeat_ = True
    parser = argparse.ArgumentParser(prog=_cmdline_)
    top_color = "gray"

    def __init__(self) -> None:
        super().__init__(complete=gdb.COMPLETE_LOCATION)
        self["peek_nb_byte"] = (16, "Hexdump N first byte(s) inside the chunk data (0 to disable)")
        self.top_color = "gray"
        return

    @parse_args
    @only_if_gdb_running
    def do_invoke(self, argv) -> None:
        max_ = 10
        last_addrs = 0

        # skip metadata -> 1
        chunks = self.get_all_chunk()[1:max_]
        # size = sum(value for value in chunks[:-1])
        size = chunks[-1] - chunks[0] + 0x50 
        # size = size - (size % 16) + 0x50
        base = chunks[0]
        cmd = gdb.execute(f"x/{size//0x8}xg {hex(base + self.repeat_count * size)}", to_string=True)

        color = [
            "sunshine_yellow",
            "mediumturquoise",
            "pink",
            "palegreen",
            "lightcoral"
        ]

        ctx_list = []
        msg = ""
        i = 0
        b = 0

        for x in cmd.splitlines():
            content = x.split(":")[1].strip().split("\t")
            addr = x.split(":")[0].split("\t")[0]
            msg += Color.colorify("0x" + addr[2:].rjust(16, "0"), "blue") + ": "
            for y in content:
                if hex(base + i*8) in [hex(h) for h in chunks]:
                    b+=1
                y = "0x" + y[2:].rjust(16, "0")
                a = gdb.parse_and_eval(y.strip()[:11])
                if a == 0x0:
                    y = f"{gdb.parse_and_eval(y)}"
                else:
                    pass
                c = color[b%5] if (base + self.repeat_count * size + i*8) in range(chunks[0], base + size) else self.top_color#("gray" if base + self.repeat_count * size + i*8 < chunks[-1] + 0x8 else self.top_color)
                msg += Color.colorify(y.ljust(18), c) + "   "
                i += 1
            if int(addr, 16) + 0x8 == chunks[-1] + 0x8:
                self.top_color = color[b%5]
                msg += f"{LEFT_ARROW}Top chunk"
            msg += "\n" if i < size//8 else ""
            last_addrs = base + i*8

        print(msg)

    def get_all_chunk(self):
        arena = GlibcHeap.get_arena(None)
        dump_start = arena.heap_base
        addr = dump_start
        chunk = GlibcHeap.GlibcChunk(addr + current_arch.ptrsize * 2)
        chunk.data = read_memory(addr, chunk.size)
        current_chunk = GlibcHeap.GlibcChunk(dump_start, from_base=True)
        arena.reset_bins_info()
        a=[]
        peek_offset = Config.get_gef_setting("heap_chunks.peek_offset")
        peek_nb = Config.get_gef_setting("heap_chunks.peek_nb_byte")
        freelist_hint_color = Config.get_gef_setting("theme.heap_freelist_hint")
        while True:
            if current_chunk.chunk_base_address == arena.top:
                a.append(current_chunk.chunk_base_address)
                break
            if current_chunk.chunk_base_address > arena.top:
                self.err("Corrupted: chunk > top")
                break
            if current_chunk.size == 0:
                # EOF
                break

            a.append(current_chunk.chunk_base_address)

            next_chunk = current_chunk.get_next_chunk()
            if next_chunk is None:
                break
            if not Address(value=next_chunk.address).valid:
                self.err("Corrupted: next_chunk_address is invalid")
                break
            current_chunk = next_chunk

        return a 

@register_command
class test(GenericCommand):
    """test"""
    _cmdline_ = "test"
    _category_ = "test"
    parser = argparse.ArgumentParser(prog=_cmdline_)

    @parse_args
    @only_if_gdb_running
    @exclude_specific_gdb_mode(mode=("qemu-system", "kgdb", "vmware", "wine"))
    def do_invoke(self, args):
        print(current_arch.ptrsize * 2)
        arena = GlibcHeap.get_arena(None)
        dump_start = arena.heap_base
        addr = dump_start
        chunk = GlibcHeap.GlibcChunk(addr + current_arch.ptrsize * 2)
        chunk.data = read_memory(addr, chunk.size)
        current_chunk = GlibcHeap.GlibcChunk(dump_start, from_base=True)
        arena.reset_bins_info()
        a=[]
        peek_offset = Config.get_gef_setting("heap_chunks.peek_offset")
        peek_nb = Config.get_gef_setting("heap_chunks.peek_nb_byte")
        freelist_hint_color = Config.get_gef_setting("theme.heap_freelist_hint")
        while True:
            if current_chunk.chunk_base_address == arena.top:
                top_str = Color.colorify("{:s} top".format(LEFT_ARROW), freelist_hint_color)
                a.append("{:s} {:s}".format(current_chunk.to_str(arena), top_str))
                break
            if current_chunk.chunk_base_address > arena.top:
                self.err("Corrupted: chunk > top")
                break
            if current_chunk.size == 0:
                # EOF
                break

            line = current_chunk.to_str(arena)

            # in or not in free-list
            info = arena.make_bins_info(current_chunk)
            print(current_chunk.chunk_base_address)
            if info:
                freelist_hint = Color.colorify(" {:s} {:s}".format(LEFT_ARROW, ", ".join(info)), freelist_hint_color)
                line += freelist_hint

            a.append(line)

            # peek nbyte
            if peek_nb:
                peek_addr = current_chunk.chunk_base_address + peek_offset
                peeked_data = read_memory(peek_addr, peek_nb)
                h = hexdump(peeked_data, 0x10, base=peek_addr)
                a.append(h)

            # goto next
            next_chunk = current_chunk.get_next_chunk()
            if next_chunk is None:
                break
            if not Address(value=next_chunk.address).valid:
                self.err("Corrupted: next_chunk_address is invalid")
                break
            current_chunk = next_chunk

        print(a)

@register_command
class ShortenOutput(GenericCommand):
    """Shorten output of memory examination to replace long zeros with 0x0."""

    _cmdline_ = "xg"
    _syntax_  = f"{_cmdline_} [length] address"
    _repeat_ = True

    @only_if_gdb_running 
    def do_invoke(self, argv):
        if argv[0].startswith("0x"):
            count = 20
            address = argv
        elif argv[0].startswith("&"):
            count = 20
            argv[0] = f'{gdb.parse_and_eval("".join(argv[0]))}'.split(" ")[0]
            address = argv
        elif argv[0].startswith("*"):
            count = 20
            address = gdb.parse_and_eval("".join(argv))
        else:
            count = int(argv[0])
            address = argv[1:]

        address = gdb.parse_and_eval("".join(address)) if type(address) == list else address
        memory = gdb.execute(f"x/{count}g {address} + {self.repeat_count * count * 8}", to_string=True)
        color = ["rose_red", "rose_red"]
        # If tcache found
        # tcache = find_all_tcache()
        # if self.repeat_count == 0 and address in tcache and len(tcache) > 1:
        #     if tcache[-1] != address:
        #         x = Color.colorify(f"- Next tcache: {hex(tcache[tcache.index(address)+1])} -", "gray")
        #         gef_print(x)
        #     if tcache[0] != address:
        #         x = Color.colorify(f"- Previous tcache: {hex(tcache[tcache.index(address)-1])} -", "gray")
        #         gef_print(x)

        max_ = max([x.split(":") for x in memory.splitlines()], key = lambda k: len(k[0]))[0]
        a = max_.split(" ")
        if len(a) >= 2:
            max_ = len(a[1]) + 1

        for i, line in enumerate(memory.splitlines()):
            # print(line)
            if (i + 1) == len(memory.splitlines()) and len(line.split(":")[1].split("\t")) % 2 != 1:
                x = []
                content = line.split(":")[1].strip().split("\t")[0]
                content = "0x" + content[2:].rjust(16, "0")
                a = gdb.parse_and_eval(content.strip()[:11])
                if a == 0x0:
                    x.append(f"{gdb.parse_and_eval(content)}")
                else:
                    x.append(content)
            else:
                ctx = line.split(":")[1].strip().split("\t")
                x = []
                for content in ctx:
                    content = "0x" + content[2:].rjust(16, "0")
                    a = gdb.parse_and_eval(content.strip()[:11])
                    if a == 0x0:
                        x.append(f"{gdb.parse_and_eval(content)}")
                    else:
                        x.append(content)

            x = f"{Color.colorify(x[0].ljust(18), ('lotus_pink' if x[0] != '0x0' else 'gray'))}   {Color.colorify(x[1].ljust(18), ('lotus_pink' if x[1] != '0x0' else 'gray')) if len(x) == 2 else ''}" 
            adrs = Color.colorify("0x" + re.search(r'^0x[0-9a-f]+', line).group(0)[2:], "blue")
            define = re.search(r"(<.+>)?(?=:)", line)
            if define.group(0):
                adrs += " " + Color.colorify(define.group(0).ljust(max_), "yellow")
                adrs = adrs.ljust(max_ + 10)
            #  + 
            # x = Color.colorify(x, color[i//2%2]) # 2 block per color
            line = f"{adrs}: {x}"
            gef_print(line)

@register_command
class fini(GenericCommand):
    """Find fini array address"""
    _cmdline_ = "fini"
    _syntax_  = f"{_cmdline_}"
    _aliases_ = ["fi"]

    @only_if_gdb_running         
    def do_invoke(self, argv):
        file_name = gdb.current_progspace().filename
        try:
            fini_address = subprocess.check_output(f"objdump -D {file_name} | grep -oP '([0-9a-f]+).+(?=<.fini_array>)'", shell=True).decode().strip()
        except:
            warn('fini_array not found!')
            return
        
        msg = Color.colorify(f".fini_array:  0x{re.sub(r'0{2,}','',fini_address)}", "blossom")
        gef_print(msg)

@register_command
class getarg(GenericCommand):
    """Get argument number from stack address"""
    _cmdline_ = "getarg"
    _syntax_  = f"{_cmdline_} stack_address"
    _aliases_ = ["ga", "geta", "arg"]

    @only_if_gdb_running         
    def do_invoke(self, argv):
        target = (int(argv[0], 16))
        base = align_address(int(gdb.selected_frame().read_register("sp")))
        ctx = Color.colorify(f'0x{hex(target)[2:].rjust(16, "0")} is argument {(target - base)//8+6}', "blossom")
        info(ctx)


if __name__ == "__main__":
    global __gef__
    __gef__ = GefCommand()
    __gef__.setup()