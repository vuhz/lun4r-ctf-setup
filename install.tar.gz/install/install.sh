#!/bin/bash

set -e

##############################
# Configuration Variables
##############################

BIN_DIR="/usr/local/bin"
PYLIB_DIR="/usr/local/pylib"
HOME_DIR="$HOME"
EXECUTABLES=("one_gadget" "rop" "gscr" "dockerinit")
CONFIG_FILES=(".gdbinit-gef.py" ".gdbinit" "gef_custom2.py")
PYTHON_SCRIPTS=("pwnaio.py")

##############################
# Function Definitions
##############################
echo_info() {
    echo -e "\e[32m[INFO]\e[0m $1"
}

echo_error() {
    echo -e "\e[31m[ERROR]\e[0m $1" >&2
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

add_to_file_if_not_exists() {
    local line="$1"
    local file="$2"
    grep -Fxq "$line" "$file" || echo "$line" >> "$file"
}

##############################
# Script Execution
##############################

echo_info "Starting installation process..."

echo_info "Updating apt package list..."
sudo apt update

echo_info "Installing system dependencies..."
sudo apt install -y \
    python3 \
    python3-pip \
    python3-dev \
    git \
    libssl-dev \
    libffi-dev \
    build-essential \
    libsqlite3-dev \
    libreadline-dev \
    libncurses5-dev \
    libncursesw5-dev \
    libbz2-dev \
    liblzma-dev \
    zlib1g-dev

echo_info "Upgrading pip..."
sudo pip3 install --upgrade pip

echo_info "Installing pwntools (pwnlib)..."
sudo pip3 install pwntools

echo_info "Verifying pwntools installation..."
python3 -c "import pwn; print('pwntools installed successfully:', pwn.__version__)"

echo_info "Installing executables..."
for exe in "${EXECUTABLES[@]}"; do
    if [ -f "$exe" ]; then
        sudo cp "$exe" "$BIN_DIR/"
        sudo chmod +x "$BIN_DIR/$exe"
        echo_info "Installed '$exe' to $BIN_DIR"
    else
        echo_error "Executable '$exe' not found in the current directory. Skipping."
    fi
done

echo_info "Installing configuration files..."
for config in "${CONFIG_FILES[@]}"; do
    if [ -f "$config" ]; then
        cp "$config" "$HOME_DIR/"
        echo_info "Copied '$config' to $HOME_DIR"
    else
        echo_error "Configuration file '$config' not found in the current directory. Skipping."
    fi
done

echo_info "Setting up Python library directory..."
sudo mkdir -p "$PYLIB_DIR"

for py_script in "${PYTHON_SCRIPTS[@]}"; do
    if [ -f "$py_script" ]; then
        sudo cp "$py_script" "$PYLIB_DIR/"
        echo_info "Copied '$py_script' to $PYLIB_DIR"
    else
        echo_error "Python script '$py_script' not found in the current directory. Skipping."
    fi
done

echo_info "Updating PYTHONPATH in .bashrc..."
add_to_file_if_not_exists "export PYTHONPATH=\$PYTHONPATH:$PYLIB_DIR/" "$HOME_DIR/.bashrc"

echo_info "Adding aliases to .bashrc..."
add_to_file_if_not_exists "alias og='one_gadget'" "$HOME_DIR/.bashrc"
add_to_file_if_not_exists "alias p='python3'" "$HOME_DIR/.bashrc"
add_to_file_if_not_exists "alias cs='checksec'" "$HOME_DIR/.bashrc"
add_to_file_if_not_exists "alias g='gdb'" "$HOME_DIR/.bashrc"

echo_info "Installation process completed successfully."

echo_info "Sourcing .bashrc to apply changes..."
source "$HOME_DIR/.bashrc"
