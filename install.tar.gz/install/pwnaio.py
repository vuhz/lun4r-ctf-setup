#!/usr/bin/python3

from pwn import *
import inspect

import __main__ 


def retrieve_name(var):
    callers_local_vars = inspect.currentframe().f_back.f_locals.items()
    return [var_name for var_name, var_val in callers_local_vars if var_val is var][0]


encode  = lambda e: p64(e) if type(e) == int and hex((e >> 56) & 0xFFFFFFFFFFFFFFFF) != 0 else e if type(e) == bytes else str(e).encode()
hexleak = lambda l: int(l[:-1] if l[-1] == '\n' else l, 16)
fixleak = lambda l: unpack(l.ljust(8, b"\x00"))
info = lambda msg: log.info(msg)
infoleak = lambda var_name, var: log.info(f"{var_name} leak: {var}")

# Modify the lambda functions to access 'p' from __main__
sla  = lambda msg, data: __main__.p.sendlineafter(msg, data)
sa   = lambda msg, data: __main__.p.sendafter(msg, data)
sl   = lambda data: __main__.p.sendline(data)
s    = lambda data: __main__.p.send(data)
r    = lambda nbytes: __main__.p.recv(nbytes)
ru   = lambda data: __main__.p.recvuntil(data)
rl   = lambda: __main__.p.recvline()


# Rotate left: 0b1001 --> 0b0011
rol = lambda val, r_bits, max_bits: \
    (val << r_bits%max_bits) & (2**max_bits-1) | \
    ((val & (2**max_bits-1)) >> (max_bits-(r_bits%max_bits)))
 
# Rotate right: 0b1001 --> 0b1100
ror = lambda val, r_bits, max_bits: \
    ((val & (2**max_bits-1)) >> r_bits%max_bits) | \
    (val << (max_bits-(r_bits%max_bits)) & (2**max_bits-1))

mangle = lambda val, adrs: \
	val ^ (adrs >> 12)



__all__ = [name for name in globals()]